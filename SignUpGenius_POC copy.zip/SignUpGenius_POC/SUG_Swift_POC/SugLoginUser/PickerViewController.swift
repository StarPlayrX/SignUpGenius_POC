///
///  PickerViewController.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/4/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

//This view is more involved because we are displays a select picker for the sign ups
//It requires an UIPicker Delegate and Data Source

class PickerViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //This holds the "view" data for the Select Picker
    var signUpPickerData: [String] = [String]()
    
    @IBOutlet weak var signUpPicker: UIPickerView!
    @IBOutlet weak var thumbnail: UIImageView!
    @IBOutlet weak var detailSignUpLite: UIBarButtonItem!
    @IBOutlet weak var urlid: UILabel!
    @IBOutlet weak var listid: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Connect data:
        self.signUpPicker.delegate = self
        self.signUpPicker.dataSource = self
        
        signUpPickerData = []
       
        for signups in sug_my_signups.data {
            let s = signups as! [String: Any]
            
            // This checks the actual type of the value and resets it accordingly
            // Some types change, especially if the JSON returns a blank value for an Integer
            
            let typeof = type(of:s["title"]!)
            let thisType = "'\(typeof)'"
            
            if thisType.range(of:"String") != nil {
                signUpPickerData.append(s["title"] as! String)
            } else if thisType.range(of:"Number") != nil  {
                signUpPickerData.append(String(s["title"] as! Int))
            }
        }

        //load first thumbnail
        if let data = sug_my_signups.data[0] as? [String:Any] {
            let imageview = thumbnail!
            let imagepath = data["thumbnail"]
            let themeid = data["themeid"] as! Int
            getImageHelper(imagepath: imagepath as! String, imageview: imageview, themeid: themeid)
        }
        
        //update the view
           signupOverview(
                urlid: urlid,
                listid: listid,
                data: sug_my_signups.data[0] as! [String : Any]
        )
    }

    //clean up
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /* Start Picker View delegate */
    
    // Number of columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return signUpPickerData.count
    }
    
    //On picker change, fill in our signup over view data
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if let data = sug_my_signups.data[row] as? [String:Any] {
            let imageview = thumbnail!
            let imagepath = data["thumbnail"]
            let themeid_str = data["themeid"] as! Int

            getImageHelper(imagepath: imagepath as! String, imageview: imageview, themeid: themeid_str)
        }
        
        //update the view
        signupOverview(
            urlid: urlid,
            listid: listid,
            data: sug_my_signups.data[row] as! [String : Any]
        )
    }
    
    // The data to return fopr the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return signUpPickerData[row]
    }
    /* End Picker View delegate */
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        /**
         * SignUp Lite is async
         * we temporarily wait for something to happen
         * this also makes it so we don't have to call this twice
         * it is automatically called the first time when the user clicks login
         **/
        
        if urlid.text != nil {
            viewSignUpLiteHelper(urlid:urlid.text!)
            repeat {} while (sug_lite_broadcast.completed == false)
        }
        
        /**
         * displays alert on login failure
         * detailView is assigned in the GUI's seque
         **/
        
        if identifier == "Detail" && sug_lite_broadcast.success == false  {
            let alertController = UIAlertController(title: "Detail View Error", message: sug_lite_broadcast.message[0] as? String, preferredStyle: .alert)
            
            let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                // OK code block can do here, for now do nothing
            }
            
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion:nil)
            return false
        }
        return true
    }
}


