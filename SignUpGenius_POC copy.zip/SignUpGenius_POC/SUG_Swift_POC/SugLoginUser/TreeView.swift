///
///  TreeView.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/10/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit
import LNZTreeView

//internal functions for Populating a TreeView's Nodes
internal func generateNodes(dict: [String : Any]) {
    
    var tempDictionary = [String : Any]()
    tempDictionary = dict
    
    var nativeDictionary = tempDictionary as Dictionary
    nativeDictionary.lowercaseKeys()
    
    let keys = Array(nativeDictionary.keys).sorted()
    
    var array = [(key: String, value: Any, type: String)]()
    
    for k in keys {
        
        let typeof = type(of:nativeDictionary[k]!)
        let foundType = "'\(typeof)'"
        
        array.append( (key: k, value: nativeDictionary[k]! as Any, type: foundType) )
    }
    
    root = rootNodes(dictionaryKeys: array)
    
    for node in root {
        
        let typeof = type(of:node.raw)
        let foundType = "\(typeof)"
        
        runner(foundType:foundType,node:node )
        
    }
}

//We may need to look for other unknown object types
//This grabs the most popular ones found
internal func runner(foundType:String, node: Node) {
    
    let empty_array = "Array0"
    let dict_str = "Dictionary"
    let single_obj_array_str = "SingleObjectArray"
    let number_str = "Number"
    
    if (foundType.range(of:empty_array) != nil) {
        //do nothing as it may cause issues
    } else if (foundType.range(of:dict_str) != nil)   {
        dothis(node: node, type: dict_str, data: node.raw as! NSDictionary)
    } else if (foundType.range(of:single_obj_array_str ) != nil) {
        
        let array = node.raw as! NSArray
        let first = array.firstObject!
        let typeof = type(of:first)
        let foundType = "\(typeof)"
        
        if (foundType.range(of: dict_str) != nil) {
            dothis(node: node, type: dict_str, data: first as! NSDictionary)
        } else if (foundType.range(of: number_str) != nil) {
            
            let a = node.raw as! Array<Any>
            let b = a[0] as! Int
            
            let array = [(key: String(node.display), value: b, type: number_str)]
            let children = handleNumber(dictionaryKeys: array)
            node.children = children
            thisDepthLevelNodes += children
            
        }
    }
}

internal func dothis (node: Node, type: String, data: NSDictionary)  {
    let children = mapDictionaryNodes(dict: data, node: node)
    
    node.children = children
    thisDepthLevelNodes += children
    
    for node in children {
        runner(foundType:node.cellType,node: node )
    }
}

internal func mapDictionaryNodes(dict: Any, node: Node) -> [Node] {
    
    var tempDictionary = [String : Any]()
    tempDictionary = dict as! [String : Any]
    
    var nativeDictionary = tempDictionary as Dictionary
    nativeDictionary.lowercaseKeys()
    
    let keys = Array(nativeDictionary.keys).sorted()
    var array = [(key: String, value: Any, type: String)]()
    
    for k in keys {
        
        let typeof = type(of:nativeDictionary[k]!)
        let foundType = "'\(typeof)'"
        
        array.append( (key: k, value: nativeDictionary[k]! as Any, type: foundType) )
    }
    
    let children = childNodes(dictionaryKeys: array)
    node.children = children
    thisDepthLevelNodes += children
    
    return children
    
}

internal func rootNodes(dictionaryKeys: [(key:String,value:Any, type: String)] ) -> [Node] {
    let nodes = Array(dictionaryKeys).map { i -> Node in
        return Node(withIdentifier: "\(arc4random()%UInt32.max)", withDisplay: "\(i.value)", withSubtitle: "\(i.key)", withCellType: "\(i.type)", withRaw: i.value)
        
    }
    return nodes
}

internal func childNodes(dictionaryKeys: [(key:String,value:Any, type: String)] ) -> [Node] {
    let nodes = Array(dictionaryKeys).map { i -> Node in
        
        if i.type.range(of:"SingleObjectArray") != nil {
            
            let iArray = i.value as! [ Any ]
            
            let typeof = type(of:iArray[0])
            let foundType = "'\(typeof)'"
            
            if iArray.count == 1 && ( foundType.range(of:"String") != nil || foundType.range(of:"Number") != nil )  {
                return Node(withIdentifier: "\(arc4random()%UInt32.max)", withDisplay: "\(iArray[0])", withSubtitle: "\(i.key)", withCellType: "String", withRaw: iArray[0])
            }
        }
        
        return Node(withIdentifier: "\(arc4random()%UInt32.max)", withDisplay: "\(i.value)", withSubtitle: "\(i.key)", withCellType: "\(i.type)", withRaw: i.value)
        
    }
    return nodes
}

internal func handleNumber(dictionaryKeys: [(key:String,value:Int, type: String)] ) -> [Node] {
    let nodes = Array(dictionaryKeys).map { i -> Node in
        return Node(withIdentifier: "\(arc4random()%UInt32.max)", withDisplay: "\(i.value)", withSubtitle: "\(i.key)", withCellType: "\(i.type)", withRaw: i.value)
    }
    return nodes
}


class CustomUITableViewCell: UITableViewCell
{
    override func layoutSubviews() {
        super.layoutSubviews();
        
        guard var imageFrame = imageView?.frame else { return }
        
        let offset = CGFloat(indentationLevel) * indentationWidth
        imageFrame.origin.x += offset
        imageView?.frame = imageFrame
    }
}

class Node: NSObject, TreeNodeProtocol {
    var display: String
    var subtitle: String
    var identifier: String
    var cellType: String
    var raw: Any
    var isExpandable: Bool {
        return children != nil
    }
    
    var children: [Node]?
    
    init(withIdentifier identifier: String, andChildren children: [Node]? = nil, withDisplay display: String, withSubtitle subtitle: String, withCellType cellType: String,  withRaw raw: Any) {
        self.display = display
        self.subtitle = subtitle
        self.identifier = identifier
        self.children = children
        self.cellType = cellType
        self.raw = raw
        
    }
}

//treeView extensions
extension TreeViewController: LNZTreeViewDataSource {
    func numberOfSections(in treeView: LNZTreeView) -> Int {
        return 1
    }
    
    func treeView(_ treeView: LNZTreeView, numberOfRowsInSection section: Int, forParentNode parentNode: TreeNodeProtocol?) -> Int {
        guard let parent = parentNode as? Node else {
            return root.count
        }
        
        return parent.children?.count ?? 0
    }
    
    func treeView(_ treeView: LNZTreeView, nodeForRowAt indexPath: IndexPath, forParentNode parentNode: TreeNodeProtocol?) -> TreeNodeProtocol {
        guard let parent = parentNode as? Node else {
            return root[indexPath.row]
        }
        
        return parent.children![indexPath.row]
    }
    
    func treeView(_ treeView: LNZTreeView, cellForRowAt indexPath: IndexPath, forParentNode parentNode: TreeNodeProtocol?, isExpanded: Bool) -> UITableViewCell {
        
        let node: Node
        
        if let parent = parentNode as? Node {
            node = parent.children![indexPath.row]
        } else {
            node = root[indexPath.row]
        }
        
        var cell = treeView.dequeueReusableCell(withIdentifier: "cell", for: node, inSection: indexPath.section)
        cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        
        if node.isExpandable {
            if isExpanded {
                cell.imageView?.image = #imageLiteral(resourceName: "index_folder_indicator_open")
            } else {
                cell.imageView?.image = #imageLiteral(resourceName: "index_folder_indicator")
            }
        } else {
            cell.imageView?.image = nil
        }
       
        if node.display == "1" {
            node.display = "true"
        } else if node.display == "0" {
            node.display = "false"
        }
        
        if (node.display.range(of:"%") != nil) {
            node.display = node.display.removingPercentEncoding!
        }
        
        if node.cellType.range(of:"Dictionary") != nil || node.cellType.range(of:"Array") != nil {
            node.display = ""
            cell.detailTextLabel?.text = node.display
            cell.textLabel?.text = node.subtitle
      
            cell.textLabel?.textColor = UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
        } else {

            cell.textLabel?.text = node.display
            cell.detailTextLabel?.text = node.subtitle
            cell.detailTextLabel?.textColor = UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
            cell.textLabel?.textColor = UIColor(displayP3Red: 246/255, green: 139/255, blue: 28/255, alpha: 1.0)
        }
        
            // UIPasteboard.general.string = String(node.display)
            
            cell.textLabel?.numberOfLines = 300
            cell.textLabel?.lineBreakMode = .byWordWrapping
            cell.textLabel?.sizeToFit()
            
            treeView.rowHeight = UITableView.automaticDimension
                    return cell
        }
    }
    
    extension TreeViewController: LNZTreeViewDelegate {
        func treeView(_ treeView: LNZTreeView, estimatedRowHeight indexPath: IndexPath, forParentNode parentNode: TreeNodeProtocol?) -> CGFloat {
            return 30
        }
}
