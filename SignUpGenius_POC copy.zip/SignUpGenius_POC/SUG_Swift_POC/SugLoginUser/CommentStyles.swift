///
///  CommentStyles.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/3/18.
///  Copyright © 2018 Todd Bruss. All rights reserved.
///


/// Swift
/// Multiline comments
/// using triple slashes
/// Without Italics


/**
 * Swift
 * Multiline comments
 * using slash-star-star star... star-star-slash method
 **/


// Apple uses this for file headers,
// but they may be easier to read with ///
// as slash is italic and triple slash is not

// Single line comment using slash slash


/*
 Apple's old documentation uses this for multiline,
 it's newer documentation uses triple slashes ///
*/


/* Single line comment */




