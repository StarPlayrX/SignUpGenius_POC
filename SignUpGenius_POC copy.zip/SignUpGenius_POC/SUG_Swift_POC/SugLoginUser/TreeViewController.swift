///
///  TreeViewController.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/4/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

//fat binary is part of tihs project
//works in Simulator and iOS
//the source code for LNZTreeView is in another app
import LNZTreeView

var thisDepthLevelNodes = [Node]()
var root: [Node]!

//treeView Classes
class TreeViewController: UIViewController {
    
    @IBOutlet weak var treeView: LNZTreeView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        treeView.register(CustomUITableViewCell.self, forCellReuseIdentifier: "cell")
        treeView.tableViewRowAnimation = .right
        generateNodes(dict: sug_lite_broadcast.data)
        treeView.resetTree() //don't know what this does
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


