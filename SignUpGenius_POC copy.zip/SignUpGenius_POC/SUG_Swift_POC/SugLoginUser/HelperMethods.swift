///
///  HelperMethods.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

//get logo helper method
internal func getImageHelper(imagepath: String, imageview: UIImageView, themeid: Int) {
    
    //other required elements
    let http = sug_secure_protocol
    let domain = sug_domain
    let imagepath = imagepath
    let themeid = themeid
    getImage(http: http, domain: domain, imagepath: imagepath, imageview: imageview, themeid: themeid)
}


internal func viewSignUpLiteHelper(urlid:String) {
    
    //other required elements
    let http = sug_secure_protocol
    let api = sug_api
    let endpoint = sug_api_viewsignuplite
    let http_method = sug_http_post_method
    let urlid = urlid
    viewSignUpLite(http: http, api: api, endpoint: endpoint, http_method: http_method, urlid: urlid)
}

internal func userLoginHelper(email:String, password:String) {
    
    //other required elements
    let http = sug_secure_protocol
    let domain = sug_domain
    let endpoint = sug_endpoint_login
    let go = sug_go
    let http_method = sug_http_post_method
    let emailKey = sug_key_email
    let passwordKey = sug_key_password
    
    UserLogin(http: http, domain: domain, endpoint: endpoint, go: go, http_method: http_method, email: email, password: password, emailKey: emailKey, passwordKey: passwordKey)
}


internal func userDetails (
    firstname: UILabel,
    lastname: UILabel,
    fullname: UILabel,
    email: UILabel,
    mobile: UILabel,
    productcode: UILabel,
    memberid: UILabel,
    parentid: UILabel,
    ismemberpro: UILabel,
    hasmemberoptins: UILabel
    ) {
    //label Dictionary allows us to call each label by a known key and we also know its type
    var labelDictionary = [String:(label:UILabel,type:String)]()
    
    let string = "String"
    let numeric = "Int"
    let boolean = "Bool"
    
    /**
     * These keys are the same as the backend
     * This lets us call the text fields by a key instead of
     * the UILabel Object name
     * that cannot be accessed dynamically without a lot of complications
     **/
    
    //strings
    labelDictionary["firstname"]        =   (label:firstname,type:string)
    labelDictionary["lastname"]         =   (label:lastname,type:string)
    labelDictionary["fullname"]         =   (label:fullname,type:string)
    labelDictionary["email"]            =   (label:email,type:string)
    labelDictionary["mobile"]           =   (label:mobile,type:string)
    labelDictionary["productcode"]      =   (label:productcode,type:string)
    
    //integers or whole numbers (numeric)
    labelDictionary["memberid"]         =   (label:memberid,type:numeric)
    labelDictionary["parentid"]         =   (label:parentid,type:numeric)
    
    //booleans 0's and 1's that we will display as true and false
    labelDictionary["ismemberpro"]      =   (label:ismemberpro,type:boolean)
    labelDictionary["hasmemberoptins"]  =   (label:hasmemberoptins,type:boolean)
    
    outputText2View(labelDictionary: labelDictionary, string: string, numeric: numeric, boolean: boolean, data: sug_login_broadcast.data)
    
}

//This updates the pickerView

internal func signupOverview (

    urlid: UILabel,
    listid: UILabel,
    data: [String:Any]
    ) {
    //label Dictionary allows us to call each label by a known key and we also know its type
    var labelDictionary = [String:(label:UILabel,type:String)]()
    
    let string = "String"
    let numeric = "Int"
    let boolean = "Bool"
    
    /**
     * These keys are the same as the backend
     * This lets us call the text fields by a key instead of
     * the UILabel Object name
     * that cannot be accessed dynamically without a lot of complications
     **/
    
    //strings
    labelDictionary["urlid"]            =   (label:urlid,type:string)

    //integers or whole numbers (numeric)
    labelDictionary["listid"]           =   (label:listid,type:numeric)

    //booleans 0's and 1's that we will display as true and false
    //labelDictionary["iscomplete"]       =   (label:iscomplete,type:boolean)

    outputText2View(labelDictionary: labelDictionary, string: string, numeric: numeric, boolean: boolean, data: data)
}

