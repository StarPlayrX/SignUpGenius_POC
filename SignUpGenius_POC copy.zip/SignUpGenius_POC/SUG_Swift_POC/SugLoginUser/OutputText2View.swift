///
///  OutputText2View.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/3/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

internal func outputText2View(
    
    labelDictionary:[String:(label:UILabel,type:String)], string: String, numeric: String, boolean: String, data: [String : Any]) {
    
    /**
     * Loop over the keys in sug_login_broadcast global variable
     * We match up the same keys in the labeDirectionary to output to the same view
     **/

    for label in data {
        
        let key = (label.key)
        let value = (label.value)
        
        //Type of object / data that is retrieved
        var thistype = labelDictionary[key]?.type
        
        //This is the label that we want to update its text
        let textObj = labelDictionary[key]?.label
        
        let typeof = type(of:value)
        let foundType = "'\(typeof)'"
        
        
        // This checks the actual type of the value and resets it accordingly
        // Some types change, especially if the JSON returns a blank value for an Integer
        
        if foundType.range(of:"String") != nil && value as? String != "0" && value as? String != "1" {
           thistype = string
        } else if foundType.range(of:"Number") != nil && value as? Int != 0 && value as? Int != 1 {
            thistype = numeric
        } else if foundType.range(of:"Boolean") != nil {
            thistype = boolean
        }
        
        if (textObj != nil ) {
            
            //If its a string, that's easy, just cast it as String
            if (thistype == string ) {
                textObj?.text = value as? String
                
            //If its an integer, we must cast as Int and then convert it to a string, otherwise the text will be blank
            } else if (thistype == numeric) {
                textObj?.text = String(value as! Int)
                
            //If its a Boolean, we must cast as Bool and then convert it to a string,  otherwise the text will be blank
            } else if (thistype == boolean) {
                textObj?.text = String(value as! Bool)
            }
        }
    }
}
