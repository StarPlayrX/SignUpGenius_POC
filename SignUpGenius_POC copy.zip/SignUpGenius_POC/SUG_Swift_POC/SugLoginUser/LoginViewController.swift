///
///  LoginViewController.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

var sug_lite_broadcast = (message: [], data: [String : Any](), success: false, completed: false)

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    //Interface outlets
    @IBOutlet weak var domain: UISegmentedControl!
    @IBOutlet weak var SugLogoImageView: UIImageView!
    @IBOutlet weak var UserEmailTextField: UITextField!
    @IBOutlet weak var UserPasswordTextField: UITextField!
    @IBOutlet weak var LoginButton: UIButton!
    
    //private login function
    private func runlogin() {
        
        let domainIndex = domain.selectedSegmentIndex
        
        //choose which way to login using segmented control
        setDomain(domainIndex:domainIndex)
     
        
        //UI Elements
        let email = UserEmailTextField.text!
        let password = UserPasswordTextField.text!
        
        userLoginHelper(email: email, password: password)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UserEmailTextField.delegate = self
        UserPasswordTextField.delegate = self

        //for debugging
        UserEmailTextField.text = "todd@signupgenius.com"
        UserPasswordTextField.text = "Testing$123"
        
        self.navigationController?.isNavigationBarHidden = false

        //UI Image View
        let imageview = SugLogoImageView!
        let imagepath = sug_logo
        let themeid = -1
        //displays the SignUpGenius Logo dynamically
        getImageHelper(imagepath:imagepath, imageview:imageview, themeid: themeid)
    
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        //presses the login button for the user
        if textField.layer == UserPasswordTextField.layer {
            textField.resignFirstResponder()
            LoginButton.sendActions(for: .touchUpInside)
            return true
        } else {
            UserPasswordTextField.becomeFirstResponder()
            return false
        }
        
    }

    /**
     * Called when the user click on the view (outside the UITextField).
     */
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        self.view.endEditing(true)
    }
    
   
    
    //when the user presses Login, them in
    @IBAction func LoginAction(_ sender: Any) {
        runlogin()
    }
    
    /**
     * determines if the seque should happen or not
     * checks if the task completed, does nothing, then
     **/
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        /**
         * UserLogin is async
         * we temporarily wait for something to happen
         * this also makes it so we don't have to call this twice
         * it is automatically called the first time when the user clicks login
         **/
        
        repeat {} while (sug_login_broadcast.completed == false)
    
        /**
         * displays alert on login failure
         * detailView is assigned in the GUI's seque
         **/
     
        if identifier == "memberInfo" && sug_login_broadcast.success == false  {
            
            let alertController = UIAlertController(title: "Login Error", message: sug_login_broadcast.message[0] as? String, preferredStyle: .alert)
            
            let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                // OK code block can do here, for now do nothing
            }
            
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion:nil)
            return false
        }
        return true
    }
}
