///
///  LowerCaseKeys.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import Foundation

///
/// convert main keys to lowercase
/// usage: dictionaryName.lowercaseKeys()
///

/// This is an extension and is called using a dot after the variable
internal extension Dictionary {
    internal mutating func lowercaseKeys() {
        for key in self.keys {
            self[String(describing: key).lowercased() as! Key] = self.removeValue(forKey: key)
        }
    }
}
