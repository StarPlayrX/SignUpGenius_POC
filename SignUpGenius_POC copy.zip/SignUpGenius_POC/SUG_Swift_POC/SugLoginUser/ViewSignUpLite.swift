///
///  ViewSignUpLite.swift
///  Sug http Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

internal func viewSignUpLite(
    http: String, api: String, endpoint: String, http_method: String, urlid: String) {
    
    sug_lite_broadcast = (message: [], data: [String : Any](), success: false, completed: false)
    
    let httpEndPoint = http + api + endpoint
    let httpURL = URL(string: httpEndPoint)
    var httpURLRequest = URLRequest(url: httpURL!)
    
    let request =
        
        [
            "customDataSet": false,
            "startFrom": 1,
            "urlID": urlid,
            "wpcookie": false
            
        ] as Dictionary
    
    // localhost and test would mishave if these steps were not followed
    // step 1: define JSON
    // step 2: give json a content type
    // step 3: define http Method as POST
    do {
        try
            httpURLRequest.httpBody = JSONSerialization.data(withJSONObject: request, options: .prettyPrinted)
            httpURLRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            httpURLRequest.httpMethod = http_method
            httpURLRequest.timeoutInterval = sug_normal_timeout
    } catch {
        sug_lite_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
    }
    
    let task = URLSession.shared.dataTask(with: httpURLRequest ) { ( returndata, response, error ) in
        
        var status = 400
        
        if response != nil {
            let result = response as! HTTPURLResponse
            status = result.statusCode
        }
        
        if status == 200 {
            
            do { var result =
                try JSONSerialization.jsonObject(with: returndata!, options: []) as! [String : Any]
                
                result.lowercaseKeys()
                result = result["returndata"] as! [String : Any]
                
                let data = result["data"]
                let success = result["success"] as! Bool
                
                if success {
                    sug_lite_broadcast = (message: ["Sign Up Lite worked."], data: data as! Dictionary, success: true, completed: true)
                } else {
                    sug_lite_broadcast = (message: ["Sign Up Lite failed."], data: [:], success: false, completed: true)
                }
            } catch {
                sug_lite_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
            }
        } else {
            sug_lite_broadcast = (message: ["E.T. was not able to phone home."], data: [:], success: false, completed: true)
            sug_lite_broadcast.completed = true;
        }
    }
    
    task.resume()
}

