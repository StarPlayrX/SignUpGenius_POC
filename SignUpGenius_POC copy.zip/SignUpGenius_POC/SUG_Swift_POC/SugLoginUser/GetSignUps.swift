///
///  GetSignUps.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

internal func getSignUps(
    memberid: Int, parentid: Int) {
    
    let endPoint = sug_secure_protocol + sug_domain + sug_go + "c.getMyCreatedSignUps"
    let endPointURL = URL(string: endPoint)!
    var endPointURLRequest = URLRequest(url: endPointURL)
    
    let request = ["showoldsignups": true, "includeimpletesignup": false] as Dictionary
    
    // localhost and test would mishave if these steps were not followed
    // step 1: define JSON
    // step 2: give json a content type
    // step 3: define http Method
    do {
        try
            endPointURLRequest.httpBody = JSONSerialization.data(withJSONObject: request, options: .prettyPrinted)
            endPointURLRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            endPointURLRequest.httpMethod = "POST"
            endPointURLRequest.timeoutInterval = sug_normal_timeout
    } catch {
        sug_lite_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
    }
    
    let task = URLSession.shared.dataTask(with: endPointURLRequest ) { ( returndata, response, error ) in
        
        var status = 400
        
        if response != nil {
            let result = response as! HTTPURLResponse
            status = result.statusCode
        }
        
        if status == 200 {
            
            do { var result =
                try JSONSerialization.jsonObject(with: returndata!, options: []) as! [String : Any]
                
                result.lowercaseKeys()
                
                let success = result["success"] as! Bool
                let message = result["message"] as! NSArray
                var data = result["data"] as! [String : Any]
                
                var signupsihavecreated : NSArray
                //convert data to lowercase keys
                if ( success ) {
                    data.lowercaseKeys()
                    signupsihavecreated = data["signupsihavecreated"] as! NSArray
                    
                    var newArray = [] as Array
                    for x in signupsihavecreated {
                        var z = x as! [String : Any]
                        z.lowercaseKeys()
                        newArray.append(z)
                    }
                    
                    usleep(2000) // 20ms timeout
                    
                    //store the result
                    sug_my_signups = (message: message as Array, data: newArray, success: success, completed: true)
                }
            } catch {
                sug_lite_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
            }
        } else {
            sug_my_signups = (message: ["An error occurred reading the sign ups you have created."], data: [], success: false, completed: true)
        }
    }
    
    task.resume()
}

