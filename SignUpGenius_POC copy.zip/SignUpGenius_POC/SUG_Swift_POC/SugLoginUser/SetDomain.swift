///
///  SetDomain.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/13/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import Foundation
import UIKit

struct Platform {
    static let isSimulator: Bool = {
        #if arch(i386) || arch(x86_64)
        return true
        #else
        return false
        #endif
    }()
}

internal func setDomain(domainIndex: Int) {
    
    sug_secure_protocol = "https://"

    if domainIndex == 0 {
        
        if Platform.isSimulator {
            sug_secure_protocol = "http://"
            sug_domain = "localhost"
            sug_api = "localapi/v1"
        } else {
            sug_secure_protocol = "http://"
            sug_domain = "10.0.10.157:3000"
            sug_api = "10.0.10.157:3002/v1"
        }
        
    } else if domainIndex == 1 {
        sug_domain = "dev.signupgenius.com"
        sug_api = "devapi.signupgenius.com/v1"
    } else if domainIndex == 2 {
        
        
        let imagepath = sug_dev_url
        
        //blank ImageView (pseudo)
        let imageview = UIImageView()
        let themeid = -1
        //displays the SignUpGenius Logo dynamically
        getImageHelper(imagepath:imagepath, imageview:imageview, themeid: themeid)
        
        sug_domain = "test.signupgenius.com"
        sug_api = "testapi.signupgenius.com/v1"
    } else if domainIndex == 3 {
        sug_domain = "www.signupgenius.com"
        sug_api = "sugapi.signupgenius.com/v1"
    }
}

