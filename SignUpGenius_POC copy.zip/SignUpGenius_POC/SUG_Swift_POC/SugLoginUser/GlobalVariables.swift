///
///  GlobalVariables.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import Foundation

/// global variables
/// may turn this into an internal function later
/// all of them are read only

let sug_api_viewsignuplite = "/signup/viewSignUpLite/"
let sug_logo = "/mobile/assets/images/signupgenius-logo.png"
let sug_endpoint_login = "c.loginUser"
let sug_go = "/SUGboxAPI.cfm?go="
let sug_key_password = "password"
let sug_key_email = "email"
let sug_http_post_method = "POST"
let sug_http_get_method = "GET"
let sug_theme_images = "/images/theme/"
let sug_login_timeout = Double(10)
let sug_normal_timeout = Double(20)
let sug_dev_url = "https://test.signupgenius.com/skylark/developercookie.cfm?password=Go+Panthers%21&submit=Submit"

/// only variable(s) that are mutable
/// This is a tuple and its children
/// can be accessed likes this:
/// sug_login_broadcast.completed = true

var sug_login_broadcast = (message: [], data: [String : Any](), success: false, completed: false)
var sug_my_signups = (message: [], data: [], success: false, completed: true)

// these now get overriden at login with segmented control
// the defaults are used to download our SignUpGenius Logo at Startup
var sug_secure_protocol = "https://"
var sug_domain = "www.signupgenius.com"
var sug_api = "sugapi.signupgenius.com/v1"
