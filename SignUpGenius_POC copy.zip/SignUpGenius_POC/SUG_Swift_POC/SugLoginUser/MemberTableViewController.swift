///
///  MemberTableViewController.swift
///  SugLoginUser
///
///  Created by Todd Bruss on 12/4/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

class MemberTableViewController: UITableViewController {
    
    var data = [(title:String,detail:String)]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        //self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        //private method
        getSignUpHelper()
        
        }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.textColor = UIColor(displayP3Red: 246/255, green: 139/255, blue: 28/255, alpha: 1.0)
        cell.textLabel?.text = data[indexPath.row].title
        cell.detailTextLabel?.text = data[indexPath.row].detail
        
        return cell
    }
    
    //get SignUps Helper Method
    //This shares data with the Table View
    //running as a private method
    private func getSignUpHelper () {
        
        if (sug_login_broadcast.success ) {
            let s = sug_login_broadcast.data.keys.sorted()
            for detail in s {
                
                let y = sug_login_broadcast.data[detail]!
                
                var title = "\(describing: y)"
                
                if title == "1" {
                    title = "true"
                } else if title == "0" {
                    title = "false"
                }
                
                data.append( (title: title, detail: detail ))
            }
            
            let local_memberid = sug_login_broadcast.data["memberid"]!
            let local_parentid = sug_login_broadcast.data["parentid"]!
            
            getSignUps(memberid: local_memberid as! Int, parentid: local_parentid as! Int)
        }
    }
}





