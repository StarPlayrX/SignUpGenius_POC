//
//  Concepts.Swift
//  SugLoginUser
//
//  Created by Todd Bruss on 1/9/19.
//  Copyright © 2019 Todd Bruss. All rights reserved.
//

import Foundation
import UIKit


func read_only() {
    
    //let is read only
    let not_mutable = "can't touch this"
    
    print(not_mutable)
    //can't touch this
    
    //note some properties in Swift of an API, the main property may have let but its sub properties may still be mututable.
}

func read_write() {
    
    //var is read and write
    var mutable = "really important record"
    mutable = "select all delete!"
    
    print(mutable)
    
    //select all delete!
}

//Where's the semi-colons?
func semi_colons() {
    //they are often not used
    let semi_colons_are_completely_optional = "no semi colon!"
    let only_required_if_you_chain_commands = "chain"; let on_the_same_line = "yup"
    
    //just printing to turn off warnings of not being used
    print(semi_colons_are_completely_optional,only_required_if_you_chain_commands,on_the_same_line)
}


// Swift Manual
// Ref: https://swift.org
func basic_Types() {
    let myString = String()
    let myInt = Int()
    let myBool = Bool()
    print(myString,myInt,myBool)
}


// Returning Data with ->
func greet(person: String) -> String {
    let greeting = "Hello, " + person + "!"
    return greeting;
    //Ref: https://docs.swift.org/swift-book/LanguageGuide/Functions.html
}


// No return uses void->
func greet(person: String) -> Void {
    let greeting = "Hello, " + person + "!"
    print(greeting)
}


// Access Control
// Ref: https://docs.swift.org/swift-book/LanguageGuide/AccessControl.html
func               a () {}  //internal (default)
internal func      b () {}  //internal
public func        c () {}  //public <- usage, public facing API
fileprivate func   d () {}  //fileprivate
private func       e () {}  //private


func ok() {
    a();b();c();d();e()
}


func Printing(Console: String) {
    
    ok() // just supressing a warning here
    
    ///dumping data
    ///instead of WriteDump('') or console.log('');
    ///Swift 4 uses:
    
    print("Hello World");
    ///If its pure data it will return bytes other complex objects such as Structs, Tuples, Dictionaries, will output correctly.
    ///If you are working with Data type you can usually convery it to a Swift type that is printable
    ///You can also try using description or debug description
    let data = "🙃".data(using: .ascii)
    print(data?.description as Any)
    
    //Ref https://www.objc.io/blog/2018/02/13/string-to-data-and-back/
}


func Optionals(value_Or_Nil: Bool) {
    
    ///many variables are read in as an Optional
    ///This container can be nil or have an actual value
    ///Often when converting JSON to a Dictionary or NSDictionary, values will contain options
    ///To savely unwrap an options use
    
    let MyOptional = Optional(["myKey":"myValue"]) // you don't actually use the keyword optional, you'll use ! or ? instead which is short hand. You will see Optional(value) when you print to the console
    let safelyUnwramp = MyOptional as NSDictionary?
    let UnsafelyUnwramp = MyOptional! as NSDictionary
    
    print(safelyUnwramp as Any, UnsafelyUnwramp as Any)
    //if you unsafely unwrap an optional and the object is nil, your app will crash.
    //Advantages: you learn to write code where the values do exist by default or you add in error checking that guards against this
    //Prevents App from contining and causing other issues down the pipeline
    
    //Objective-C allows 'Null' and would continue and would often cause unexpected behavior
    //Ref https://developer.apple.com/documentation/swift/optional
}


func space() {
    
    //Class
    class Starship  {
        var prefix: String?
        var name: String
        init(name: String, prefix: String? = nil) {
            self.name = name
            self.prefix = prefix
        }
        
        var fullname: String {
            return (prefix! + " " + name)
        }
    }
    
    let nnc1701 = Starship(name: "Enterprise", prefix: "USS")
    
    print(nnc1701.fullname)
    
    //USS Enterprise
}

func structs() {
    
    struct User {
        var username: String
        var email: String
        var name: String
    }
    
    var user = User(username: "farhansyed", email: "farhansyed123@gmail.com", name: "Farhan Syed")
    
    print(user.username)
    
    user.username = "fargenugen"
    // fargenugen
    
    // https://medium.com/ios-os-x-development/structs-in-swift-for-newbies-bf64f3d40f68

}


//arguments in func's are actually called Tuples
func Tuples(color: UIColor, make: String, model: String, cost: Int) {
    
    //Tuples can also be variables are can be considered a custom type like a Struct
    //They are defined much like a Struct is
    var tuple = (wheels: "Four", frame: "unibody", chrome: true, doors: 4)
    
    // you can later define parts like this
    tuple.wheels = "Three"
    tuple.frame = "fullbody"
    //Both Structs and Tuples are a prefined Size
    
    print(tuple)
}

func Dictionaries() {
    
    let urlid = "https://waroftheworlds.com"
    
    var dictionary = [
        "customDataSet": false,
        "startFrom": 1,
        "urlID": urlid,
        "wpcookie": false
        
        ] as Dictionary
    
    print(dictionary)
    
    //variations
    dictionary = ["customDataSet": false ] as [String : Any]
    
    // ref: https://developer.apple.com/documentation/swift/dictionary
    
    //for reading deeplay nested values, cast the Dictioanry to an NSDictioanry
    //when you encounter an NSArray that's in the mix, cast the object as NSArray and cast the child you want as a NSDictonary and repeat

    func spxReadChannels(data: [String : Any]) {
        
        let result = data as NSDictionary
        
        let r = result.value(forKeyPath: "ModuleListResponse.moduleList.modules")!
        
        let m = r as? NSArray
        
        let o = m![0] as! NSDictionary
        
        let d = o.value( forKeyPath: "moduleResponse.contentData.channelListing.channels") as! NSArray
        
        print(d)
    }
    
    // ref: https://stackoverflow.com/questions/25475463/how-to-access-deeply-nested-dictionaries-in-swift
}
