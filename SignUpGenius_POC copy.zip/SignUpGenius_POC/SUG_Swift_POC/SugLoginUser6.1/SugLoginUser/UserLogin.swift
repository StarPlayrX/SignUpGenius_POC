///
///  UserLogin.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

internal func UserLogin(
    http: String, domain: String, endpoint: String, go: String, http_method: String,
    email: String, password: String, emailKey: String, passwordKey: String) {
   
    sug_login_broadcast = (message: [], data: [String : Any](), success: false, completed: false)
    
    let loginEndPoint = http + domain + go + endpoint
    let loginURL = URL(string: loginEndPoint)
    var loginURLRequest = URLRequest(url: loginURL!)

    let request = [passwordKey: password, emailKey: email] as Dictionary

    // localhost and test would mishave if these steps were not followed
    // step 1: define JSON
    // step 2: give json a content type
    // step 3: define http Method as POST
    do {
       try
        loginURLRequest.httpBody = JSONSerialization.data(withJSONObject: request, options: .prettyPrinted)
        loginURLRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        loginURLRequest.httpMethod = http_method
        loginURLRequest.timeoutInterval = sug_login_timeout

    } catch {
        sug_login_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
    }

    let task = URLSession.shared.dataTask(with: loginURLRequest ) { ( returndata, response, error ) in
        
        var status = 400
        
        if response != nil {
            let result = response as! HTTPURLResponse
            status = result.statusCode
        }
        
        if status == 200 {
            
            do { var result =
                try JSONSerialization.jsonObject(with: returndata!, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String : Any]

                result.lowercaseKeys()
                let success = result["success"] as! Bool
                let message = result["message"] as! NSArray
                var data = result["data"] as! [String : Any]
                
                //convert data to lowercase keys
                if ( success ) {
                    data.lowercaseKeys()
                }
                
                //Let's the seque know where are done
                sug_login_broadcast = (message: message as Array, data: data as Dictionary, success: success, completed: true)
                
                var sendNote = Notification(name: Notification.Name(rawValue: "didLogin"))
                sendNote.userInfo = data
                NotificationCenter.default.post( sendNote )
                
            } catch {
                sug_login_broadcast = (message: [(error.localizedDescription)], data: [:], success: false, completed: true)
                
                print(error)
            }
        } else {
            sug_login_broadcast = (message: ["E.T. was not able to phone home."], data: [:], success: false, completed: true)
            
            print(status)
        }
    }
    
    task.resume()
    
}
