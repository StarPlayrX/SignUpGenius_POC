///
///  GetImage.swift
///  Sug Login Demo
///
///  Created by Todd Bruss on 11/30/18.
///  Copyright © 2018 SignUpGenius. All rights reserved.
///

import UIKit

/// this internal function fetches cached logo from cloudflare
/// or www.signupgenius.com if it's not cache

internal func getImage
    (http: String, domain: String, imagepath: String, imageview: UIImageView, themeid: Int) {
    
    var concatURL = "";
    
    //full path was returned from the server
    if imagepath.hasPrefix("http") {
        concatURL = imagepath
    } else {
        //create the path
        concatURL = http + domain + imagepath
        
        let themedir = "/images/theme/"
        let suffix = ".jpg"
        let dashlarge = "-large"
        let themeid_str = String(themeid)
        let thispath = themedir + themeid_str + suffix
        
        //grabs large thumbnail when logic test passes
        if thispath == imagepath || imagepath.range(of:"/mobile/assets/images/signupgenius-logo.png") == nil && themeid > 0 {
            concatURL = http + domain + themedir + themeid_str + dashlarge + suffix
        }
    }
    
    let imageURL = URL(string:concatURL)!
    
    let task = URLSession.shared.dataTask(with: imageURL ) { ( data, response, error ) in
        
        var status = 400
        
        if response != nil {
            let result = response as! HTTPURLResponse
            status = result.statusCode
        }
        
        
        if status == 200 && concatURL != sug_dev_url {
            
            /**
             * UI Image currently does not support SVG
             * It supports PNG and should also support PDF
             * you may be able to support SVG with this:
             * https://stackoverflow.com/questions/35691839/how-to-display-svg-image-using-swift
             **/
            
            
            let imageData = UIImage(data: data!)!
            
            //Prevents crash when updating the main thread
            DispatchQueue.main.async {
                imageview.image = imageData
            }
            
            //you could alos use NSImag
        } else {
            DispatchQueue.main.async {
                imageview.image = UIImage()
            }
        }
    }
    
    task.resume()
}


